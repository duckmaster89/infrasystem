from django.apps import AppConfig


class ItInfraSystemConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'it_infra_system'
